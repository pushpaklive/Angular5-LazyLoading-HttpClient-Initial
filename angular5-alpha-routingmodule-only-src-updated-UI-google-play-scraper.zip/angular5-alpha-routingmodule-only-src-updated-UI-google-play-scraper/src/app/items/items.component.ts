import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common.service';
import { Router } from "@angular/router";

@Component({
  selector: 'app-items',
  templateUrl: './items.component.html',
  styleUrls: ['./items.component.css']
})
export class ItemsComponent implements OnInit {

  constructor(private commonService: CommonService, private router : Router) { }
  allItems;
  ngOnInit() {
    this.allItems = this.commonService.getItems();
    console.log("allItems : "+(this.allItems))
  }

  showItemDetails(index){
    var obj = {'index':index, 'secretKey': 'sdhsjkdkdjsujun-djsf***khjdfkh88990po'}
    this.router.navigate(['/itemdetails/:index', obj])
  }

}
