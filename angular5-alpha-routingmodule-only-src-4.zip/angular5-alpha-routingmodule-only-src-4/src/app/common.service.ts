import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
@Injectable()
export class CommonService {

  constructor(private http: HttpClient) { }

  items = ["Item A", "Item B", "Item C", "Item D", "Item E", "Item F", "Item G"];

  getItems() {
    return this.items;
  }

  getPosts(){
    return this.http.get('https://jsonplaceholder.typicode.com/posts');
  }

  getFeeds(){
    return this.http.get("http://localhost:3000/feeds");
  }

  getTopScorers(){
    return this.http.get("http://localhost:3000/topscorers-stockexchange");
  }
}
