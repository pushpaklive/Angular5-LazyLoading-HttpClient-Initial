import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common.service';
import { Chart } from 'chart.js';

@Component({
  selector: 'app-topscorers',
  templateUrl: './topscorers.component.html',
  styleUrls: ['./topscorers.component.css']
})
export class TopscorersComponent implements OnInit {

  constructor(private commonService: CommonService) { }
  topScorerCompanies;
  pointChangeArray = [];
  topCompanyNames = [];
  bgColors = ["#00FF00", "#008080", "#FF0000", "#DF3A01", "#1E90FF", "#5858FA", "#FFFF00", "#A9F5BC", "#3B0B39", "#B40404"];
  type;
  type1;
  data;
  options;
  
  ngOnInit() {
    this.commonService.getTopScorers().
      subscribe((topCompanies) => {
        this.topScorerCompanies = JSON.parse(JSON.stringify(topCompanies));
        for (var i = 0; i < this.topScorerCompanies.length; i++) {
          this.pointChangeArray.push(this.topScorerCompanies[i].pointChange);
          this.topCompanyNames.push(this.topScorerCompanies[i].symbol)
        }
        this.type = 'doughnut';
        this.type1 = "line";
        this.data = {
          labels: this.topCompanyNames,
          datasets: [
            {
              label: "Points change",
              data: this.pointChangeArray,
              "backgroundColor": this.bgColors
            }
          ]
        };
        this.options = {
          responsive: true,
          maintainAspectRatio: false,
          "animation": {
            "animateScale": true,
            "animateRotate": false
          }
        };
        console.log(this.pointChangeArray);
      });
  }

}
