import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ItemsComponent } from './items/items.component';
import { ItemDetailsComponent } from './item-details/item-details.component';
import { PostsComponent } from './posts/posts.component';
import { FeedsComponent } from './feeds/feeds.component';
import { TopscorersComponent } from './topscorers/topscorers.component';

const routes: Routes = [
  {
    path: 'customers',
    loadChildren: './customers/customers.module#CustomersModule'
  },
  {
    path: 'orders',
    loadChildren: './orders/orders.module#OrdersModule'
  },
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full'
  },
  {
    path:'items',
    component: ItemsComponent
  },
  {
    path:'itemdetails/:index',
    component: ItemDetailsComponent
  },
  {
    path: 'posts',
    component: PostsComponent
  },
  {
    path: 'feeds',
    component: FeedsComponent
  },
  {
    path: 'topscorers',
    component: TopscorersComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
