var express = require('express');
var cors = require('cors')
var axios = require('axios')
const app = express();
var StockExchangeAPI = require('indian-stock-exchange');
 
var NSEAPI = StockExchangeAPI.NSE;
var BSEAPI = StockExchangeAPI.BSE;

app.use(cors())

app.get('/feeds', function(req, res){
    /* axios({
        method:'get',
        url:'https://timesofindia.indiatimes.com/rssfeeds/-2128821991.cms',
        responseType:'application/json'
      })
        .then(function(response) {
        console.log(response);
        res.send(response.data);
      }); */
    let Parser = require('rss-parser');
    let parser = new Parser();

    (async () => {
     
      let feed = await parser.parseURL('https://timesofindia.indiatimes.com/rssfeeds/-2128936835.cms');
      console.log(feed.title);
      
      feed.items.forEach(item => {
        //console.log(item.title + ':' + item.link);
        /* itemTitleList.push(feed.title)
        itemLinksList.push(feed.link); */
      });
     res.send(JSON.stringify(feed.items));
    })();

})

app.get('/topscorers-stockexchange', function(req, res){
    BSEAPI.getTopTurnOvers()
    .then(function (response) { 
     /*  console.log("NSE Sensex data: ",response.data); //return the api data
      console.log("End"); */
      res.send(response.data);
    });
     
/*     NSEAPI.getIndices()
    .then(function (response) { 
      console.log("BSE Sensex data: ",response.data); //return the api data
    }); */
})

app.listen(3000, function(){
    console.log("** ApP lIsTeNinG tO poRt 3oO0 ****")
})