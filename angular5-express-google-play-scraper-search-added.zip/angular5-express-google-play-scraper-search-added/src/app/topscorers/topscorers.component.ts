import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common.service';
import { Chart } from 'chart.js';

@Component({
  selector: 'app-topscorers',
  templateUrl: './topscorers.component.html',
  styleUrls: ['./topscorers.component.css']
})
export class TopscorersComponent implements OnInit {

  constructor(private commonService: CommonService) { }
  topScorerCompanies;
  
  ngOnInit() {
    this.commonService.getTopScorers().
      subscribe((topCompanies) => {
        this.topScorerCompanies = JSON.parse(JSON.stringify(topCompanies));
      });
  }

}
