import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
@Injectable()
export class CommonService {

  constructor(private http: HttpClient) { }

  items = ["Item A", "Item B", "Item C", "Item D", "Item E", "Item F", "Item G"];

  getItems() {
    return this.items;
  }

  getPosts(){
    return this.http.get('https://jsonplaceholder.typicode.com/posts');
  }

  getFeeds(){
    return this.http.get("http://localhost:3000/feeds");
  }

  getTopScorers(){
    return this.http.get("http://localhost:3000/topscorers-stockexchange");
  }

  getBSEGainer(){
    return this.http.get("http://localhost:3000/gainers");
  }

  getTodaysAstrologyReport(){
    return this.http.get('http://localhost:3000/today-birth-astro');
  }

  getStockInfo(companyName){
    var obj = {"companyName":companyName}
    return this.http.post('http://localhost:3000/stockinfo',obj);
  }

  getBestOfGooglePlay(){
    return this.http.get("http://localhost:3000/bestofgoogleplay");
  }

  searchGooglePlay(searchTerm){
    var obj = {"searchTerm": searchTerm}
    return this.http.post('http://localhost:3000/searchgoogleplay',obj);
  }
}
