import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-search-google-play',
  templateUrl: './search-google-play.component.html',
  styleUrls: ['./search-google-play.component.css']
})
export class SearchGooglePlayComponent implements OnInit {
  searchTerm;
  allApps;
  constructor(private commonService: CommonService) { }

  ngOnInit() {
  }

  searchGooglePlayStore(searchText){
    console.log(searchText);
    this.commonService.searchGooglePlay(searchText)
        .subscribe((appResults) => {
          console.log(appResults);
          this.allApps = appResults;
        })
  }

}
