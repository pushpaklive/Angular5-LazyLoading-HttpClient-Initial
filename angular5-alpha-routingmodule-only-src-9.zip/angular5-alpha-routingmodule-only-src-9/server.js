var express = require('express');
var cors = require('cors')
var axios = require('axios')
var bodyParser = require('body-parser')
const app = express();
var StockExchangeAPI = require('indian-stock-exchange');

var NSEAPI = StockExchangeAPI.NSE;
var BSEAPI = StockExchangeAPI.BSE;

const IndianAstrology = require('indian-astrology');

app.use(cors())
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ urlencoded: false }))

app.get('/feeds', function (req, res) {
    let Parser = require('rss-parser');
    let parser = new Parser();

    (async () => {

        let feed = await parser.parseURL('https://timesofindia.indiatimes.com/rssfeeds/-2128936835.cms');
        console.log(feed.title);

        feed.items.forEach(item => {
            //console.log(item.title + ':' + item.link);
            /* itemTitleList.push(feed.title)
            itemLinksList.push(feed.link); */
        });
        res.send(JSON.stringify(feed.items));
    })();

})

app.get('/topscorers-stockexchange', function (req, res) {
    BSEAPI.getTopTurnOvers()
        .then(function (response) {
            /*  console.log("NSE Sensex data: ",response.data); //return the api data
             console.log("End"); */
            res.send(response.data);
        });

    /*     NSEAPI.getIndices()
        .then(function (response) { 
          console.log("BSE Sensex data: ",response.data); //return the api data
        }); */
})

app.get('/gainers', function (req, res) {
    BSEAPI.getGainers()
        .then(function (response) {
            res.send(response.data);
        });

    /*     NSEAPI.getIndices()
        .then(function (response) { 
          console.log("BSE Sensex data: ",response.data); //return the api data
        }); */
})

app.get('/today-birth-astro', function (req, res) {
    res.send(IndianAstrology.getTodaysDetails(false));
})

app.post('/stockinfo', bodyParser.json(), function (req, res) {
    console.log((req.body.companyName))
    const si = require('stock-info');
    si.getSingleStockInfo(req.body.companyName).then((stock) => {
        console.log(JSON.stringify(stock));
        res.send(JSON.stringify(stock));
    }).catch(err => console.log("Error here in stock info"));
})

app.get('/bestofgoogleplay', function (req, res) {
    var gplay = require('google-play-scraper');

    gplay.list({
        category: gplay.category.GAME_ACTION,
        collection: gplay.collection.TOP_FREE,
        num: 10
    })
        .then(results => res.send(results));
})
/* Below is blocked */
/* app.get('/getsuperhero', function(req, res){
'use strict';
 
const shdb = require('superherodb-parser');
 
const heroName = 'hulk';
 
shdb.search(heroName).then((res) => {
  console.log('Search result : ');
  console.log(JSON.stringify(res, null, 2));
});
}) */

/* app.get('/mapmyindia', function(req, res){
    var mapsdk = require('mapmyindia-sdk-nodejs');
    // testing reverse geocoding
    // Parameters are API_KEY, Latitude, Longitude
    // this function returns promise which can be used to handle success or failure response accrodingly.
     /* mapsdk.reverseGeoCodeGivenLatiLongi('6gw7l67qcse64w8sdhfpiqr1c76bumrc',26.5645,85.9914).then(function(response)
     {
         console.log(JSON.stringify(response));
         res.send((response.results[0].poi))
     }).catch(function(ex){
         console.log('came in catch');
         console.log(ex);
     });
//testing routes
// Parameters are API_KEY, Starting point latitude, Starting point longitude, Ending point latitude, Ending point longitude
// this function returns promise which can be used to handle success or failure response accrodingly.
mapsdk.getRoute('6gw7l67qcse64w8sdhfpiqr1c76bumrc',28.111,77.111,28.22,77.22).then(function(response)
{
   res.send(response)
}).catch(function(ex){
    console.log('came in catch');
    console.log(ex);
});

}) */

app.listen(3000, function () {
    console.log("** ApP lIsTeNinG tO poRt 3oO0 ****")
})