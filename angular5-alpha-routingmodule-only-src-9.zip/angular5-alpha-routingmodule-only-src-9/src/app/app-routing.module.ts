import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ItemsComponent } from './items/items.component';
import { ItemDetailsComponent } from './item-details/item-details.component';
import { PostsComponent } from './posts/posts.component';
import { FeedsComponent } from './feeds/feeds.component';
import { TopscorersComponent } from './topscorers/topscorers.component';
import { TopscorerschartComponent } from './topscorerschart/topscorerschart.component';
import { GainersComponent } from './gainers/gainers.component';
import { TodaysAstrologyComponent } from './todays-astrology/todays-astrology.component';
import { StockinfoComponent } from './stockinfo/stockinfo.component';
import { GooglePlayComponent } from './google-play/google-play.component';

const routes: Routes = [
  {
    path: 'customers',
    loadChildren: './customers/customers.module#CustomersModule'
  },
  {
    path: 'orders',
    loadChildren: './orders/orders.module#OrdersModule'
  },
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full'
  },
  {
    path:'items',
    component: ItemsComponent
  },
  {
    path:'itemdetails/:index',
    component: ItemDetailsComponent
  },
  {
    path: 'posts',
    component: PostsComponent
  },
  {
    path: 'feeds',
    component: FeedsComponent
  },
  {
    path: 'topscorers',
    component: TopscorersComponent
  },
  {
    path : 'topscorerschart',
    component: TopscorerschartComponent
  },
  {
    path:'gainers',
    component: GainersComponent
  },
  {
    path: 'astrologyreportfortoday',
    component: TodaysAstrologyComponent
  },
  {
    path: 'stockinfo',
    component: StockinfoComponent
  },
  {
    path: 'bestofgoogleplay',
    component: GooglePlayComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
