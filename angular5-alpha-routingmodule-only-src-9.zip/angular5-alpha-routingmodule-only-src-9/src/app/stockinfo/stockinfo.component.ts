import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-stockinfo',
  templateUrl: './stockinfo.component.html',
  styleUrls: ['./stockinfo.component.css']
})
export class StockinfoComponent implements OnInit {
  companyName: string = '';
  stockInfo;
  chartData1 = [];
  labels1 = [];
  type;
  data;
  options;
  bgColors = ["#00FF00", "#008080", "#FF0000", "#DF3A01", "#1E90FF", "#5858FA", "#FFFF00", "#A9F5BC", "#3B0B39", "#B40404"];
  constructor(private commonService: CommonService) { }

  ngOnInit() {
    //this.commonService.getStockInfo(this.companyName).subscribe(stockDetails => this.stockInfo = stockDetails)
  }

  getStockInfo() {
    console.log("getStockInfo() this.companyName : " + this.companyName);
    this.commonService.getStockInfo(this.companyName).subscribe((stockDetails) => {
      this.chartData1 = [];
      this.labels1 = [];
      this.stockInfo = stockDetails;
      this.chartData1.push(this.stockInfo.regularMarketPrice);
      this.labels1.push("Regular Market Price");
      /* this.chartData1.push(this.stockInfo.regularMarketChange);
      this.labels1.push("Regular Market Change"); */
      this.chartData1.push(this.stockInfo.postMarketPrice);
      this.labels1.push("Pre Market Price");
      /* this.chartData1.push(this.stockInfo.preMarketChange);
      this.labels1.push("Pre Market Change"); */
      this.type = 'doughnut';
      this.data = {
        labels: this.labels1,
        datasets: [
          {
            label: "Pre and Regular Prices Comparison",
            data: this.chartData1,
            "backgroundColor": this.bgColors
          }
        ]
      };
      this.options = {
        responsive: true,
        maintainAspectRatio: false
      };
      console.log("stockInfo : " + JSON.stringify(this.stockInfo));
    })
  }

}
