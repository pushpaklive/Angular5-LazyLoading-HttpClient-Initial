import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css']
})
export class PostsComponent implements OnInit {

  constructor(private commonService: CommonService) { }
  postsApiResponse;
  ngOnInit() {
    this.commonService.getPosts()
        .subscribe((apiResponse) => {
          this.postsApiResponse = apiResponse;
          console.log(" this.postsApiResponse : "+( this.postsApiResponse));
        });
  }

}
