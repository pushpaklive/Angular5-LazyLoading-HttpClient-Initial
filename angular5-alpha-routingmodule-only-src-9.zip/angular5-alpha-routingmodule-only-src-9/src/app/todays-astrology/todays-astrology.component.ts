import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-todays-astrology',
  templateUrl: './todays-astrology.component.html',
  styleUrls: ['./todays-astrology.component.css']
})
export class TodaysAstrologyComponent implements OnInit {
  todaysAstroReport;
  constructor(private commonService: CommonService) { }

  ngOnInit() {
    this.commonService.getTodaysAstrologyReport()
      .subscribe((astroReport) => {
        this.todaysAstroReport = astroReport;
      });
  }

}
