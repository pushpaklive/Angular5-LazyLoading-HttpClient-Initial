var express = require('express');
var cors = require('cors')
var axios = require('axios')
const app = express();

app.use(cors())

app.get('/feeds', function(req, res){
    /* axios({
        method:'get',
        url:'https://timesofindia.indiatimes.com/rssfeeds/-2128821991.cms',
        responseType:'application/json'
      })
        .then(function(response) {
        console.log(response);
        res.send(response.data);
      }); */
    let Parser = require('rss-parser');
    let parser = new Parser();

    (async () => {
     
      let feed = await parser.parseURL('https://timesofindia.indiatimes.com/rssfeeds/-2128936835.cms');
      console.log(feed.title);
      
      feed.items.forEach(item => {
        //console.log(item.title + ':' + item.link);
        /* itemTitleList.push(feed.title)
        itemLinksList.push(feed.link); */
      });
     res.send(JSON.stringify(feed.items));
    })();

})

app.listen(3000, function(){
    console.log("** ApP lIsTeNinG tO poRt 3oO0 ****")
})