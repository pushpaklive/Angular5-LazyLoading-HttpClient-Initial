import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { CommonService } from './common.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'app';
  gitApiResponse;
  constructor(private http: HttpClient, private commonService: CommonService){}
  ngOnInit(){
      this.commonService.getItems().subscribe(githubObj => this.gitApiResponse = githubObj)
  }
}
