import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-feeds',
  templateUrl: './feeds.component.html',
  styleUrls: ['./feeds.component.css']
})
export class FeedsComponent implements OnInit {
  feeds;
  constructor(private commonService: CommonService) { }
  ngOnInit() {
    this.commonService.getFeeds().subscribe((feeds) => { this.feeds = feeds; });
  }

}
