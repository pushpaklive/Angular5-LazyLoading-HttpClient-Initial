import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { ChartModule } from 'angular2-chartjs';

import { AppComponent } from './app.component';
import { CommonService } from './common.service';
import { ItemsComponent } from './items/items.component';
import { ItemDetailsComponent } from './item-details/item-details.component';
import { HttpClientModule } from '@angular/common/http';
import { PostsComponent } from './posts/posts.component';
import { FeedsComponent } from './feeds/feeds.component';
import { TopscorersComponent } from './topscorers/topscorers.component';
import { TopscorerschartComponent } from './topscorerschart/topscorerschart.component';
import { GainersComponent } from './gainers/gainers.component';
import { TodaysAstrologyComponent } from './todays-astrology/todays-astrology.component';


@NgModule({
  declarations: [
    AppComponent,
    ItemsComponent,
    ItemDetailsComponent,
    PostsComponent,
    FeedsComponent,
    TopscorersComponent,
    TopscorerschartComponent,
    GainersComponent,
    TodaysAstrologyComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ChartModule
  ],
  providers: [CommonService],
  bootstrap: [AppComponent]
})
export class AppModule { }

