import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-google-links',
  templateUrl: './google-links.component.html',
  styleUrls: ['./google-links.component.css']
})
export class GoogleLinksComponent implements OnInit {
  googlelinks = [];
  searchTerm;
  constructor(private commonService: CommonService) { }

  ngOnInit() {
  }

  searchGoogle(){
    this.googlelinks = [];
    this.commonService.searchForGoogleLinks(this.searchTerm)
         .subscribe((links) => {
           console.log(JSON.parse(JSON.stringify(links)).length);
           for(var i=0; i < JSON.parse(JSON.stringify(links)).length; i++){
               this.googlelinks.push(JSON.parse(JSON.stringify(links))[i]);
           }
         })
  }

}
