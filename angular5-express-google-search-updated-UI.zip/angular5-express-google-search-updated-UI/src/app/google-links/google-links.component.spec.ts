import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GoogleLinksComponent } from './google-links.component';

describe('GoogleLinksComponent', () => {
  let component: GoogleLinksComponent;
  let fixture: ComponentFixture<GoogleLinksComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GoogleLinksComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GoogleLinksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
