import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchGooglePlayComponent } from './search-google-play.component';

describe('SearchGooglePlayComponent', () => {
  let component: SearchGooglePlayComponent;
  let fixture: ComponentFixture<SearchGooglePlayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchGooglePlayComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchGooglePlayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
