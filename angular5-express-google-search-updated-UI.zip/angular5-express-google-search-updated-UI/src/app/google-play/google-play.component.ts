import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-google-play',
  templateUrl: './google-play.component.html',
  styleUrls: ['./google-play.component.css']
})
export class GooglePlayComponent implements OnInit {
  topApps;
  constructor(private commonService: CommonService) { }

  ngOnInit() {
    this.commonService.getBestOfGooglePlay()
         .subscribe((topAppsDetails) => {
           this.topApps = topAppsDetails;
         })
  }

}
