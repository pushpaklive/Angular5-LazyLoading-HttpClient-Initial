import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-gainers',
  templateUrl: './gainers.component.html',
  styleUrls: ['./gainers.component.css']
})
export class GainersComponent implements OnInit {
  gainers;
  todayClosingIndex = [];
  gainerCompanyNames = [];
  type;
  type1;
  data;
  options;
  bgColors = ["#00FF00", "#008080", "#FF0000", "#DF3A01", "#1E90FF", "#5858FA", "#FFFF00", "#A9F5BC", "#3B0B39", "#B40404"];
  constructor(private commonService : CommonService) { }

  ngOnInit() {
    this.commonService.getBSEGainer()
       .subscribe((gainerCompanies)=>{
          this.gainers = gainerCompanies;
          this.gainers = JSON.parse(JSON.stringify(gainerCompanies));
        for (var i = 0; i < this.gainers.length; i++) {
          this.todayClosingIndex.push(this.gainers[i].todayClose);
          this.gainerCompanyNames.push(this.gainers[i].symbol)
        }
        this.type = 'doughnut';
        this.type1 = "line";
        this.data = {
          labels: this.gainerCompanyNames,
          datasets: [
            {
              label: "Points change",
              data: this.todayClosingIndex,
              "backgroundColor": this.bgColors
            }
          ]
        };
        this.options = {
          responsive: true,
          maintainAspectRatio: false,
          "animation": {
            "animateScale": true,
            "animateRotate": false
          }
        };
        console.log(this.todayClosingIndex);
       })
  }

}
