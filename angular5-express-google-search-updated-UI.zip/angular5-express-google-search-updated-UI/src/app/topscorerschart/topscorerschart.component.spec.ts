import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TopscorerschartComponent } from './topscorerschart.component';

describe('TopscorerschartComponent', () => {
  let component: TopscorerschartComponent;
  let fixture: ComponentFixture<TopscorerschartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TopscorerschartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TopscorerschartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
